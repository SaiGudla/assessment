package controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dal.DAL;
import dal.ProductFactory;

/**
 * Servlet implementation class CheckAvailability
 */
@WebServlet("/CheckAvailability")
public class CheckAvailability extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CheckAvailability() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println(request.getParameter("pincode"));
		Integer pin = Integer.parseInt(request.getParameter("pincode"));
		Integer pid = Integer.parseInt(request.getParameter("pid"));
		DAL d = ProductFactory.getProductsDALImpl();
		if (d.checkAvailability(pin, pid)) {
			response.getWriter().write("Available for Shipping");
		} else {
			response.getWriter().write("Shipping Not available for the given pincode");

		}
	}

}
